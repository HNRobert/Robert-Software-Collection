The files in this directory are necessary for the portable application to
function.  There is normally no need to directly access or alter any of the
files within these directories.
